﻿using Microsoft.EntityFrameworkCore;

namespace Core_CodeFirst.Models
{
    public partial class MyFirstDBContext : DbContext
    {

        public MyFirstDBContext(DbContextOptions<MyFirstDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employees { get; set; }

    }
}
